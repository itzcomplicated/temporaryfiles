package com.example.seatanimation.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.seatanimation.R
import com.example.seatanimation.custom.BladderHighlightView
import com.example.seatanimation.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val homeViewModel: HomeViewModel by activityViewModels()

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        homeViewModel.leftRightSwitch.observe(viewLifecycleOwner, Observer {
            if (it) {
                binding.imageViewSeat.setImageResource(R.drawable.seat_r)
            } else {
                binding.imageViewSeat.setImageResource(R.drawable.seat_l)
            }
            binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.NONE)
            binding.bladderHighlightView.setLeftOrRight(it)
        })
        homeViewModel.topBackBladder.observe(viewLifecycleOwner, Observer {
            if (it) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.UPPER_BACK)
            } else if (binding.bladderHighlightView.getSelection() == BladderHighlightView.Selection.UPPER_BACK) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.NONE)
            }
        })
        homeViewModel.middleBackBladder.observe(viewLifecycleOwner, Observer {
            if (it) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.MIDDLE_BACK)
            } else if (binding.bladderHighlightView.getSelection() == BladderHighlightView.Selection.MIDDLE_BACK) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.NONE)
            }
        })
        homeViewModel.bottomBackBladder.observe(viewLifecycleOwner, Observer {
            if (it) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.LOWER_BACK)
            } else if (binding.bladderHighlightView.getSelection() == BladderHighlightView.Selection.LOWER_BACK) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.NONE)
            }
        })
        homeViewModel.sideBackBladder.observe(viewLifecycleOwner, Observer {
            if (it) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.SIDE_BACK)
            } else if (binding.bladderHighlightView.getSelection() == BladderHighlightView.Selection.SIDE_BACK) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.NONE)
            }
        })
        homeViewModel.firstSeatBladder.observe(viewLifecycleOwner, Observer {
            if (it) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.FIRST_SEAT)
            } else if (binding.bladderHighlightView.getSelection() == BladderHighlightView.Selection.FIRST_SEAT) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.NONE)
            }
        })
        homeViewModel.secondSeatBladder.observe(viewLifecycleOwner, Observer {
            if (it) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.SECOND_SEAT)
            } else if (binding.bladderHighlightView.getSelection() == BladderHighlightView.Selection.SECOND_SEAT) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.NONE)
            }
        })
        homeViewModel.sideSeatBladder.observe(viewLifecycleOwner, Observer {
            if (it) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.SIDE_SEAT)
            } else if (binding.bladderHighlightView.getSelection() == BladderHighlightView.Selection.SIDE_SEAT) {
                binding.bladderHighlightView.setSelection(BladderHighlightView.Selection.NONE)
            }
        })
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}