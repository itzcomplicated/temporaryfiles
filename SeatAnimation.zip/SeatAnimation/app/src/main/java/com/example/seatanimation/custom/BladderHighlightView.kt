package com.example.seatanimation.custom

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Resources
import android.graphics.*
import android.graphics.Shader.TileMode
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import com.example.seatanimation.R
import kotlin.math.abs


class BladderHighlightView
@JvmOverloads
constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = R.attr.bladderHighlightStyle
) : View(context, attrs, defStyleAttr) {

    private var paint: Paint = Paint()
    private var path: Path = Path()
    private var width = 0f
    private var height = 0f

    private var valueAnimator: ValueAnimator? = null

    init {
        val attrs = context.obtainStyledAttributes(
            attrs,
            R.styleable.BladderHighlightView,
            defStyleAttr,
            0
        )

        paint.color = Color.argb(150, 52, 113, 235)
        paint.strokeWidth = 2F
        paint.style = Paint.Style.FILL_AND_STROKE
        paint.isAntiAlias = true

        val res: Resources = resources

        val leftRes = attrs.getColor(R.styleable.BladderHighlightView_leftRes, 0)
        val rightRes = attrs.getColor(R.styleable.BladderHighlightView_rightRes, 0)
        val leftBitmap = BitmapFactory.decodeResource(res, leftRes)
        val rightBitmap = BitmapFactory.decodeResource(res, rightRes)
    }

    private fun updateGradient(x: Float, y: Float) {

        println("updateGradient: " + x + " " + y + " at " + System.currentTimeMillis())
        gradientMatrix.setTranslate(x, y)
       // gradientPaint.shader.setLocalMatrix(gradientMatrix)
        postInvalidateOnAnimation()
    }

    private var currentSelection = Selection.NONE

    fun setSelection(selection: Selection) {
        currentSelection = selection
        invalidate()
    }

    fun getSelection(): Selection {
        return currentSelection
    }

    private var leftOrRight = false

    fun setLeftOrRight(value: Boolean) {
        leftOrRight = value
        invalidate()
    }

    private fun getXValue(x: Float): Float {
        return if (leftOrRight)
            width - x
        else x
    }

    enum class Selection {
        NONE,
        UPPER_BACK,
        MIDDLE_BACK,
        LOWER_BACK,
        SIDE_BACK,
        FIRST_SEAT,
        SECOND_SEAT,
        SIDE_SEAT
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        width = w.toFloat()
        height = h.toFloat()

        line1BackPointA = PointF(0.46153F * width, 0.34179F * height)
        line1BackPointB = PointF(0.75824F * width, 0.38379F * height)
        line2BackPointA = PointF(0.45683F * width, 0.37695F * height)
        line2BackPointB = PointF(0.74097F * width, 0.41699F * height)
        line3BackPointA = PointF(0.45683F * width, 0.41016F * height)
        line3BackPointB = PointF(0.72370F * width, 0.45215F * height)
        line4BackPointA = PointF(0.45055F * width, 0.44140F * height)
        line4BackPointB = PointF(0.70645F * width, 0.48535F * height)
        line5BackPointA = PointF(0.44584F * width, 0.47558F * height)
        line5BackPointB = PointF(0.69702F * width, 0.51855F * height)
        line6BackPointA = PointF(0.43485F * width, 0.50684F * height)
        line6BackPointB = PointF(0.68445F * width, 0.55078F * height)
        line7BackPointA = PointF(0.43171F * width, 0.54199F * height)
        line7BackPointB = PointF(0.67190F * width, 0.58887F * height)
        line8BackPointA = PointF(0.42543F * width, 0.56934F * height)
        line8BackPointB = PointF(0.67190F * width, 0.61426F * height)

        line1SeatPointA = PointF(0.39874F * width, 0.62012F * height)
        line1SeatPointB = PointF(0.64364F * width, 0.66699F * height)
        line2SeatPointA = PointF(0.36735F * width, 0.63476F * height)
        line2SeatPointB = PointF(0.61695F * width, 0.6875F * height)
        line3SeatPointA = PointF(0.33438F * width, 0.65039F * height)
        line3SeatPointB = PointF(0.59655F * width, 0.70019F * height)
        line4SeatPointA = PointF(0.30298F * width, 0.66308F * height)
        line4SeatPointB = PointF(0.57456F * width, 0.71680F * height)
        line5SeatPointA = PointF(0.27315F * width, 0.67285F * height)
        line5SeatPointB = PointF(0.55259F * width, 0.73242F * height)
        line6SeatPointA = PointF(0.22920F * width, 0.68555F * height)
        line6SeatPointB = PointF(0.52747F * width, 0.75195F * height)


        //Left bladder back
        leftBackPoints.add(PointF(0.4144427F * width, 0.28808594F * height))
        leftBackPoints.add(PointF(0.4599686F * width, 0.3388672F * height))
        leftBackPoints.add(PointF(0.46153846F * width, 0.375F * height))
        leftBackPoints.add(PointF(0.42857143F * width, 0.57128906F * height))
        leftBackPoints.add(PointF(0.4364207F * width, 0.5996094F * height))
        leftBackPoints.add(PointF(0.38618523F * width, 0.58984375F * height))
        leftBackPoints.add(PointF(0.31868133F * width, 0.546875F * height))
        leftBackPoints.add(PointF(0.29827315F * width, 0.5205078F * height))
        leftBackPoints.add(PointF(0.30769232F * width, 0.48828125F * height))
        leftBackPoints.add(PointF(0.37048665F * width, 0.34765625F * height))
        leftBackPoints.add(PointF(0.40816328F * width, 0.29589844F * height))

        //Right bladder back
        rightBackPoints.add(PointF(0.68288857F * width, 0.6464844F * height))
        rightBackPoints.add(PointF(0.7346939F * width, 0.65722656F * height))
        rightBackPoints.add(PointF(0.7394034F * width, 0.6357422F * height))
        rightBackPoints.add(PointF(0.78492934F * width, 0.6171875F * height))
        rightBackPoints.add(PointF(0.81632656F * width, 0.5371094F * height))
        rightBackPoints.add(PointF(0.8430141F * width, 0.37597656F * height))
        rightBackPoints.add(PointF(0.8618524F * width, 0.32714844F * height))
        rightBackPoints.add(PointF(0.79434854F * width, 0.3515625F * height))
        rightBackPoints.add(PointF(0.76138145F * width, 0.3828125F * height))
        rightBackPoints.add(PointF(0.722135F * width, 0.44921875F * height))
        rightBackPoints.add(PointF(0.68602824F * width, 0.5527344F * height))
        rightBackPoints.add(PointF(0.67189956F * width, 0.6123047F * height))
        rightBackPoints.add(PointF(0.68288857F * width, 0.64941406F * height))

        //Left bladder seat

        leftSeatPoints.add(PointF(0.10675039F * width, 0.7128906F * height))
        leftSeatPoints.add(PointF(0.10361067F * width, 0.6894531F * height))
        leftSeatPoints.add(PointF(0.16169545F * width, 0.64453125F * height))
        leftSeatPoints.add(PointF(0.29042387F * width, 0.60058594F * height))
        leftSeatPoints.add(PointF(0.32182103F * width, 0.59472656F * height))
        leftSeatPoints.add(PointF(0.38618523F * width, 0.5917969F * height))
        leftSeatPoints.add(PointF(0.43799058F * width, 0.6015625F * height))
        leftSeatPoints.add(PointF(0.2543171F * width, 0.6767578F * height))
        leftSeatPoints.add(PointF(0.10675039F * width, 0.71777344F * height))

        //Right bladder seat
        rightSeatPoints.add(PointF(0.4913658F * width, 0.8066406F * height))
        rightSeatPoints.add(PointF(0.5102041F * width, 0.76660156F * height))
        rightSeatPoints.add(PointF(0.5243328F * width, 0.7529297F * height))
        rightSeatPoints.add(PointF(0.64835167F * width, 0.6699219F * height))
        rightSeatPoints.add(PointF(0.68288857F * width, 0.6484375F * height))
        rightSeatPoints.add(PointF(0.72527474F * width, 0.65625F * height))
        rightSeatPoints.add(PointF(0.72056514F * width, 0.6748047F * height))
        rightSeatPoints.add(PointF(0.70957613F * width, 0.69433594F * height))
        rightSeatPoints.add(PointF(0.63265306F * width, 0.75878906F * height))
        rightSeatPoints.add(PointF(0.5729984F * width, 0.7949219F * height))
        rightSeatPoints.add(PointF(0.5196232F * width, 0.8125F * height))

        gradiantBitmap = createGradientBitmap()
    }


    private var line1BackPointA = PointF(0F, 0F)
    private var line1BackPointB = PointF(0F, 0F)
    private var line2BackPointA = PointF(0F, 0F)
    private var line2BackPointB = PointF(0F, 0F)
    private var line3BackPointA = PointF(0F, 0F)
    private var line3BackPointB = PointF(0F, 0F)
    private var line4BackPointA = PointF(0F, 0F)
    private var line4BackPointB = PointF(0F, 0F)
    private var line5BackPointA = PointF(0F, 0F)
    private var line5BackPointB = PointF(0F, 0F)
    private var line6BackPointA = PointF(0F, 0F)
    private var line6BackPointB = PointF(0F, 0F)
    private var line7BackPointA = PointF(0F, 0F)
    private var line7BackPointB = PointF(0F, 0F)
    private var line8BackPointA = PointF(0F, 0F)
    private var line8BackPointB = PointF(0F, 0F)

    private var line1SeatPointA = PointF(0F, 0F)
    private var line1SeatPointB = PointF(0F, 0F)
    private var line2SeatPointA = PointF(0F, 0F)
    private var line2SeatPointB = PointF(0F, 0F)
    private var line3SeatPointA = PointF(0F, 0F)
    private var line3SeatPointB = PointF(0F, 0F)
    private var line4SeatPointA = PointF(0F, 0F)
    private var line4SeatPointB = PointF(0F, 0F)
    private var line5SeatPointA = PointF(0F, 0F)
    private var line5SeatPointB = PointF(0F, 0F)
    private var line6SeatPointA = PointF(0F, 0F)
    private var line6SeatPointB = PointF(0F, 0F)

    private val leftBackPoints = mutableListOf<PointF>()
    private val rightBackPoints = mutableListOf<PointF>()
    private val leftSeatPoints = mutableListOf<PointF>()
    private val rightSeatPoints = mutableListOf<PointF>()

    private var gradiantBitmap: Bitmap? = null
    private val gradientPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        // Highlight only the areas already touched on the canvas
        //xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
    }
    private val green = Color.GREEN
    private val gradientColors =
        intArrayOf(green, modifyAlpha(green, 0.80f),
            modifyAlpha(green, 0.05f))
    private val gradientMatrix = Matrix()

    private fun modifyAlpha(color: Int, alpha: Float): Int {
        return color and 0x00ffffff or ((alpha * 255).toInt() shl 24)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        valueAnimator = ValueAnimator.ofFloat(0f, 300f).apply {
            addUpdateListener {
                //
            updateGradient(it.animatedValue as Float, it.animatedValue as Float)
            }
            duration = 1500L
            repeatMode = ValueAnimator.RESTART
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }

    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        when (currentSelection) {
            Selection.UPPER_BACK -> drawUpperBladder(canvas)
            Selection.MIDDLE_BACK -> drawMiddleBladder(canvas)
            Selection.LOWER_BACK -> drawLowerBladder(canvas)
            Selection.SIDE_BACK -> {
                drawLeftBackBladder(canvas)
                drawRightBackBladder(canvas)
            }
            Selection.FIRST_SEAT -> drawFirstSeatBladder(canvas)
            Selection.SECOND_SEAT -> drawSecondSeatBladder(canvas)
            Selection.SIDE_SEAT -> {
                drawLeftSeatBladder(canvas)
                drawRightSeatBladder(canvas)
            }
        }
        gradiantBitmap?.let {
            canvas.drawBitmap(
                it,
                getXValue(line8BackPointA.x),
                line1BackPointA.y,
                paint
            )
        }
    }

    val gradientColorStart = Color.argb(250, 52, 113, 235)
    val gradientColorEnd = Color.argb(150, 52, 113, 235)
/*    val shader = LinearGradient(
        0F,
        0F,
        0F,
        200F,
        gradientColorStart,
        gradientColorEnd,
        TileMode.CLAMP
    )*/
    val shader = RadialGradient(
    150F, 250F, 300F,
    gradientColors, null, Shader.TileMode.CLAMP
    )

    private fun createGradientBitmap(): Bitmap {
        val w = abs(line8BackPointA.x - line1BackPointB.x).toInt()
        val h = abs(line1BackPointA.y - line8BackPointB.y).toInt()
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        //paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        gradientPaint.shader = shader
        path.reset()
        val startX = line8BackPointA.x
        val startY = line1BackPointA.y
        path.moveTo(getXValue(line1BackPointA.x - startX), line1BackPointA.y - startY)
        path.lineTo(getXValue(line1BackPointB.x - startX), line1BackPointB.y - startY)
        path.lineTo(getXValue(line8BackPointB.x - startX), line8BackPointB.y - startY)
        path.lineTo(getXValue(line8BackPointA.x - startX), line8BackPointA.y - startY)
        path.close();
        canvas.drawPath(path, gradientPaint);
        //canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        return bitmap
    }

    private fun drawUpperBladder(canvas: Canvas) {
        path.reset()
        path.moveTo(getXValue(line1BackPointA.x), line1BackPointA.y)
        path.lineTo(getXValue(line1BackPointB.x), line1BackPointB.y)
        path.lineTo(getXValue(line3BackPointB.x), line3BackPointB.y)
        path.lineTo(getXValue(line3BackPointA.x), line3BackPointA.y)
        path.close();
        canvas.drawPath(path, paint);
    }

    private fun drawMiddleBladder(canvas: Canvas) {
        path.reset()
        path.moveTo(getXValue(line3BackPointA.x), line3BackPointA.y)
        path.lineTo(getXValue(line3BackPointB.x), line3BackPointB.y)
        path.lineTo(getXValue(line6BackPointB.x), line6BackPointB.y)
        path.lineTo(getXValue(line6BackPointA.x), line6BackPointA.y)
        path.close();
        canvas.drawPath(path, paint);
    }

    private fun drawLowerBladder(canvas: Canvas) {
        path.reset()
        path.moveTo(getXValue(line6BackPointA.x), line6BackPointA.y)
        path.lineTo(getXValue(line6BackPointB.x), line6BackPointB.y)
        path.lineTo(getXValue(line8BackPointB.x), line8BackPointB.y)
        path.lineTo(getXValue(line8BackPointA.x), line8BackPointA.y)
        path.close();
        canvas.drawPath(path, paint);
    }

    private fun drawFirstSeatBladder(canvas: Canvas) {
        path.reset()
        path.moveTo(getXValue(line1SeatPointA.x), line1SeatPointA.y)
        path.lineTo(getXValue(line1SeatPointB.x), line1SeatPointB.y)
        path.lineTo(getXValue(line4SeatPointB.x), line4SeatPointB.y)
        path.lineTo(getXValue(line4SeatPointA.x), line4SeatPointA.y)
        path.close();
        canvas.drawPath(path, paint);
    }

    private fun drawSecondSeatBladder(canvas: Canvas) {
        path.reset()
        path.moveTo(getXValue(line3SeatPointA.x), line3SeatPointA.y)
        path.lineTo(getXValue(line3SeatPointB.x), line3SeatPointB.y)
        path.lineTo(getXValue(line6SeatPointB.x), line6SeatPointB.y)
        path.lineTo(getXValue(line6SeatPointA.x), line6SeatPointA.y)
        path.close();
        canvas.drawPath(path, paint);
    }

    private fun drawLeftBackBladder(canvas: Canvas) {
        path.reset()
        for ((index, point) in leftBackPoints.withIndex()) {
            if (index == 0)
                path.moveTo(getXValue(point.x), point.y)
            else
                path.lineTo(getXValue(point.x), point.y)
        }
        path.close()
        canvas.drawPath(path, paint)
    }

    private fun drawRightBackBladder(canvas: Canvas) {
        path.reset()
        for ((index, point) in rightBackPoints.withIndex()) {
            if (index == 0)
                path.moveTo(getXValue(point.x), point.y)
            else
                path.lineTo(getXValue(point.x), point.y)
        }
        path.close()
        canvas.drawPath(path, paint)
    }

    private fun drawLeftSeatBladder(canvas: Canvas) {
        path.reset()
        for ((index, point) in leftSeatPoints.withIndex()) {
            if (index == 0)
                path.moveTo(getXValue(point.x), point.y)
            else
                path.lineTo(getXValue(point.x), point.y)
        }
        path.close()
        canvas.drawPath(path, paint)
    }

    private fun drawRightSeatBladder(canvas: Canvas) {
        path.reset()
        for ((index, point) in rightSeatPoints.withIndex()) {
            if (index == 0)
                path.moveTo(getXValue(point.x), point.y)
            else
                path.lineTo(getXValue(point.x), point.y)
        }
        path.close()
        canvas.drawPath(path, paint)
    }

}

