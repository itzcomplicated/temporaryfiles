package com.example.seatanimation

import android.os.Bundle
import android.view.Menu
import android.widget.CompoundButton
import androidx.activity.viewModels
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.example.seatanimation.databinding.ActivityMainBinding
import com.example.seatanimation.ui.home.HomeViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private var lastSelectedCheckBox: CompoundButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.appBarMain.toolbar)

        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)
        val homeViewModel: HomeViewModel by viewModels()

        val switchLeftRightItem = navView.menu.findItem(R.id.switchLeftRight)
        (switchLeftRightItem.actionView as SwitchCompat).setOnCheckedChangeListener { button, value ->
            homeViewModel.setLeftRightSwitch(value)
            lastSelectedCheckBox = button
        }
        val checkTopBackBladderItem = navView.menu.findItem(R.id.checkTopBackBladder)
        (checkTopBackBladderItem.actionView as CompoundButton).setOnCheckedChangeListener { button, value ->
            homeViewModel.setTopBack(value)
            lastSelectedCheckBox = button
        }
        val checkMiddleBackBladderItem = navView.menu.findItem(R.id.checkMiddleBackBladder)
        (checkMiddleBackBladderItem.actionView as CompoundButton).setOnCheckedChangeListener { button, value ->
            homeViewModel.setMiddleBack(value)
            lastSelectedCheckBox = button
        }
        val checkLowerBackBladderItem = navView.menu.findItem(R.id.checkLowerBackBladder)
        (checkLowerBackBladderItem.actionView as CompoundButton).setOnCheckedChangeListener { button, value ->
            homeViewModel.setBottomBack(value)
            lastSelectedCheckBox = button
        }
        val checkSideBackBladderItem = navView.menu.findItem(R.id.checkSideBackBladder)
        (checkSideBackBladderItem.actionView as CompoundButton).setOnCheckedChangeListener { button, value ->
            homeViewModel.setSideBack(value)
            lastSelectedCheckBox = button
        }
        val checkFirstSeatBladderItem = navView.menu.findItem(R.id.checkFirstSeatBladder)
        (checkFirstSeatBladderItem.actionView as CompoundButton).setOnCheckedChangeListener { button, value ->
            homeViewModel.setFirstSeat(value)
            lastSelectedCheckBox = button
        }
        val checkSecondSeatBladderItem = navView.menu.findItem(R.id.checkSecondSeatBladder)
        (checkSecondSeatBladderItem.actionView as CompoundButton).setOnCheckedChangeListener { button, value ->
            homeViewModel.setSecondSeat(value)
            lastSelectedCheckBox = button
        }
        val checkSideSeatBladderItem = navView.menu.findItem(R.id.checkSideSeatBladder)
        (checkSideSeatBladderItem.actionView as CompoundButton).setOnCheckedChangeListener { button, value ->
            homeViewModel.setSideSeat(value)
            lastSelectedCheckBox = button
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
}