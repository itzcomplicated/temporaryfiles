package com.example.seatanimation.ui.home

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {

    val leftRightSwitch = MutableLiveData<Boolean>()

    fun setLeftRightSwitch(value: Boolean){
        leftRightSwitch.value = value
    }

    val topBackBladder = MutableLiveData<Boolean>()

    fun setTopBack(value: Boolean) {
        topBackBladder.value = value
        println("TCA HomeViewModel: topBackBladder.value = value")
    }

    val middleBackBladder = MutableLiveData<Boolean>()

    fun setMiddleBack(value: Boolean) {
        middleBackBladder.value = value
    }

    val bottomBackBladder = MutableLiveData<Boolean>()

    fun setBottomBack(value: Boolean) {
        bottomBackBladder.value = value
    }

    val sideBackBladder = MutableLiveData<Boolean>()

    fun setSideBack(value: Boolean) {
        sideBackBladder.value = value
    }

    val firstSeatBladder = MutableLiveData<Boolean>()

    fun setFirstSeat(value: Boolean) {
        firstSeatBladder.value = value
    }

    val secondSeatBladder = MutableLiveData<Boolean>()

    fun setSecondSeat(value: Boolean) {
        secondSeatBladder.value = value
    }

    val sideSeatBladder = MutableLiveData<Boolean>()

    fun setSideSeat(value: Boolean) {
        sideSeatBladder.value = value
    }
}